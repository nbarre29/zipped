export class MockRepository {
  someFunction() {
    console.log('This is mock user repository');
  }
}
