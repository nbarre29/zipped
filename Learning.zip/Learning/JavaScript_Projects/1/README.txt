PS C:\Users\shrav\Desktop\New folder (3)\DI> npm install
PS C:\Users\shrav\Desktop\New folder (3)\DI>npm run dev


http://localhost:3000/test

http://localhost:3000/dev