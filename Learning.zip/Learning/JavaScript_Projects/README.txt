1) https://www.youtube.com/watch?v=I6_ka5fMQCo  (Dependency Injection in NodeJS)
https://github.com/Mohammad-Faisal/dependency-injection-nodejs


2) 

