# "Express JS Tutorial - User Authorization"

✅ [Check out my YouTube Channel with all of my tutorials](https://www.youtube.com/DaveGrayTeachesCode).

**Description:**

This repository shares the code applied during the Youtube tutorial. The tutorial is part of a [Node.js & Express for Beginners Playlist](https://www.youtube.com/playlist?list=PL0Zuz27SZ-6PFkIxaJ6Xx_X46avTM1aYw) on my channel.

[YouTube Tutorial](https://youtu.be/Nlg0JrUt0qg) for this repository.

I suggest completing my [8 hour JavaScript course tutorial video](https://youtu.be/EfAl9bwzVZk) if you are new to Javascript.

### Academic Honesty

**DO NOT COPY FOR AN ASSIGNMENT** - Avoid plagiargism and adhere to the spirit of this [Academic Honesty Policy](https://www.freecodecamp.org/news/academic-honesty-policy/).

My Notes:::::
PS C:\Users\shrav\Desktop\Cleanup_1\user_auth-main> npm i dotenv jsonwebtoken cookie-parser

PS C:\Users\shrav\Desktop\Cleanup_1\user_auth-main> node
Welcome to Node.js v20.2.0.
Type ".help" for more information.

> require('crypto').randomBytes(64).toString('hex')
> '7c1dad6ef3bfe680bc7a4851fd37d274858f7ac79cde4503061ce9a5c2d6ea79cdec6ab9d3c1ecd3da92a3e2f5dffd07bd4cf70423d3c04abedde36c209abcfd'
> require('crypto').randomBytes(64).toString('hex')
> '32114ab649db960f257ae3f9ea7c650e7ded8b794bcde07e46b4d9786fa532b8d15fd88871aeded459f0806a833e34918901958a46c9ac86f115423e841a0e71'

PS C:\Users\shrav\Desktop\Cleanup_1\user_auth-main> npm run dev
