http://www.informit.com/articles/article.aspx?p=2191423
http://www.intertech.com/Blog/java-8-tutorial-default-and-static-methods-guide/