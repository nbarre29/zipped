0:  
1: see how the deposit method in BankAccount.java is modified to add few more steps. We had added synchronized keyword to the method.
2: See how we added the synchronized block in deposit method.
3: 