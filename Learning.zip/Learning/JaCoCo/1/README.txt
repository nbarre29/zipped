https://mkyong.com/maven/maven-jacoco-code-coverage-example/


From Eclipse right click pom.xml
Run As -> Maven test
JaCoCo code coverage report will be generated at, maven-code-coverage/target/site/jacoco/index.html


1. Green – Code is tested or covered.
2. Red – Code is not tested or covered.
3. Yellow – Code is partially tested or covered.