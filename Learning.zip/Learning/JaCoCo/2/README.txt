https://mkyong.com/maven/jacoco-java-code-coverage-maven-example/


From Eclipse right click pom.xml
Run As -> Maven test