From Eclipse right click pom.xml
Run As -> Maven test
JaCoCo code coverage report will be generated at,
jacoco-codecoverage-master/target/my-reports/index.html