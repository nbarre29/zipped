# Maven – JaCoCo code coverage example
Maven, JUnit 5 + JaCoCo example.

Project Link - https://www.mkyong.com/maven/maven-jacoco-code-coverage-example/

## How to run this project?
```
$ git clone https://github.com/mkyong/maven-examples.git
$ cd maven-code-coverage
$ mvn clean test

# view report at 'target/site/jacoco/index.html'
```



Same as in Folder 1, just the package name updated to naveen instead of mkyong