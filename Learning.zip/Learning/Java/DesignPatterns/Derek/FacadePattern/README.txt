We create a simplified interface that performs many other actins behind the scenes.

* Can I withdraw $50 from the bank?
   * Check if the checking account is valid.
   * Check if the security code is valid.
   * Check if funds are available.
   * Make changes accordingly


_________________________________________________________________________________________________

The Facade pattern basically says that you should simplify your methods so that much of what is done is in the background. In technical terms you should decouple the client from the sub components needed to perform an operation. 