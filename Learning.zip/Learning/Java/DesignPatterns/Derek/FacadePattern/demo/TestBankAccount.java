package demo;

public class TestBankAccount {
	
	public static void main(String[] args){
		
		BankAccountFacade accessingBank = new BankAccountFacade(12345678, 1234);
		
		accessingBank.withdrawCash(50.00);
		
		accessingBank.withdrawCash(990.00);
		
	}
	
}

/*
OUTPUT:::

Welcome to ABC Bank
We are happy to give you your money if we can find it

Withdrawal Complete: Current Balance is 950.0
Transaction Complete

Error: You don't have enough money
Current Balance: 950.0
Transaction Failed

*/


/*


accessingBank.withdrawCash(50.00);
		
accessingBank.withdrawCash(900.00);
                
accessingBank.depositCash(200.00);



Welcome to ABC Bank
We are happy to give you your money if we can find it

Withdrawal Complete: Current Balance is 950.0
Transaction Complete

Withdrawal Complete: Current Balance is 50.0
Transaction Complete

Deposit Complete: Current Balance is 250.0
Transaction Complete

*/
