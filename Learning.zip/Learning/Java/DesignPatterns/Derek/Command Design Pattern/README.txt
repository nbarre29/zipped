The Command design pattern allows you to store a list of commands for later use. With it you can store multiple commands in a class to use over and over.


_____________________________________________________________________________________
ELECTRONICDEVICE.JAVA
TELEVISION.JAVA (RECEIVER)
COMMAND.JAVA
TURNTVON.JAVA (COMMAND)
TURNTVOFF.JAVA (COMMAND)
TURNTVUP.JAVA (COMMAND)
DEVICEBUTTON.JAVA (INVOKER)
TVREMOTE.JAVA
PLAYWITHREMOTE.JAVA  ( Class with main() method )
RADIO.JAVA (RECEIVER)
TURNITALLOFF.JAVA (COMMAND)

_____________________________________________________________________________________

Q:) the purpose of “Command Pattern”
That is a very good question. You’d basically use the Command Pattern when you need to decouple the object that needs actions to be performed from the objects that perform those actions. Most design patterns try to decouple code. The goal is to have objects request an action to be performed and know that the object knows exactly how to perform those actions. The objects don’t need to know how the job is done they just want it done. 

Q:) Why did you use TVRomote class just to return Television in this way: ElectronicDevice newDevice = TVRemote.getDevice(); when you could have used: ElectronicDevice newDevice = new Television(); am I missing something? 
I didn’t fully develop the TVRemote. The idea was to have numerous versions of getDevice, so that I could control things other then just the television. Sorry that I didn’t explain that better. 

