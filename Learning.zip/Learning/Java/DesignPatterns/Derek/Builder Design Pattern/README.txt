You use the builder design pattern when you want to have many classes help in the creation of an object. By having different classes build the object you can then easily create many different types of objects without being forced to rewrite code.

The Builder pattern provides a different way to make complex objects like you�d make using the Abstract Factory design pattern.
_____________________________________________________________________________________

RobotPlan.java
Robot.java
RobotBuilder.java
OldRobotBuilder.java
RobotEngineer.java
TestRobotBuilder.java ( Class with main() method )
_____________________________________________________________________________________