Is A? versus Has A?

Is A? Helps you decide if a class should extend another
    Is a "Dog" an "Animal"?    Answer is Yes here so Animal is a superclass for Dog
	Is a "Dog" a "Cat"?        Answer is No here so Cat cannot be a superclass for Dog
Has A? Helps you decide if something is a field
    "Dog" has a "Height"
	
When to use inheritance?
1) The subclass Is A superclass "Dog Is An Animal"
2) When a subclass needs most of the methods in a superclass
   Almost every method in Animal is used in Dog.
3) Don't use inheritance just to reuse code, or they don't have a Is A relationship
4) Avoid duplicate code
5) Changes to the superclass code is instantly reflected in subclasses
6) User knows that all subclasses have all of the methods of the superclass