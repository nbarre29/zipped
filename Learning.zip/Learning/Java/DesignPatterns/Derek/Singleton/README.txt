Comment: I have a question related to the concept of Singleton. In a singleton, If we were to maintain only a single 'instance' of a class, why maintain an instance at all? Why can't we just make the constructor private and make the rest of? all methods static? What is the advantage of creating a single instance versus using a (static) class with all static methods?
Derek:  you use static classes when you are absolutely positive that every method will only be used in a utility type way. It is normally pretty easy to change a singleton if you require multiple instances down the road. That isn't true with a static class

Comment: u got a typo there - printed out playerOneTiles twice...
got me puzzled for a few minutes.
Derek: Sorry about that. I'm? getting better at avoiding mistakes.

_________________________________
GetTheTiles.java
ScrabbleTest.java
ScrabbleTestThreads.java
Singleton.java