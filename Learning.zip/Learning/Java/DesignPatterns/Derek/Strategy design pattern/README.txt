if you need to dynamically change an algorithm used by an object at run time. 
The pattern also allows you to eliminate code duplication. It separates behavior from super and subclasses. 
--------------------------------------------------------------------------
Comment: Watched most of the design patterns. Had just one question about the explanation at this pattern. You’re talking about Composition (Animal.java) but i had the feeling it was Aggregation? I find it hard to tell the difference. (I know about there definitions) 

Derek: yes I misspoke and you are correct. Most people just refer to everything as composition, but you understand the difference. 
--------------------------------------------------------------------------
Comment: Why don’t you encapsulate the flyingType field in the Animal class with protected modifier so that the sub-classes can directly access to this field but the clients can’t, they must use the setFlyingAbility method instead.

Derek: You could definitely do that. There are many ways to create each design pattern. They are but a guide for writing flexible code 
--------------------------------------------------------------------------
Comment: I’m confused.. how does the Animal class know about Flys.. maybe I need to watch the video again. 

Derek: Flys flyingType is stored in every Animal object as a field. In the Bird class we then give it the ability to fly flyingType = new ItFlys(). 
--------------------------------------------------------------------------
Comment: I was wondering how the Animal.java know about the Flys interface???I could n’t understand how they are related….

Derek: 
// Composition allows you to change the capabilities of objects at run time
public Flys flyingType;

The Flys object is stored in every Animal. It can then be changed if needed without disturbing the code
