Design Patterns::: Design patterns are solutions to software design problems we find again and again in real-world application development.

Creational:
Creational patterns are ones that create objects for us, rather than having us instantiate objects directly. This gives our program more flexibility in deciding which objects need to be created for a given case.

Structural:
These concern class and object composition. They use inheritance to compose interfaces and define ways to compose objects to obtain new functionality.

Behavioral:
Most of these design patterns are specifically concerned with communication between objects.

Creational Design Patterns:::
Singleton Pattern
Factory Pattern
Abstract Factory Pattern
Builder Pattern
Prototype Pattern

Structural Design Patterns:::
Adapter Pattern
Composite Pattern
Proxy Pattern
Flyweight Pattern
Facade Pattern
Bridge Pattern
Decorator Pattern

Behavioral Design Patterns:::
Template Method Pattern
Mediator Pattern
Chain of Responsibility Pattern
Observer Pattern
Strategy Pattern
Command Pattern
State Pattern
Visitor Pattern
Iterator Pattern
Memento Pattern
