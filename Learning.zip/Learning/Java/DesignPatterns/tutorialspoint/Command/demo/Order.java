package demo;

public interface Order {
	   void execute();
	}
