package demo;

public interface Shape {
	void draw();
}
