package com.cakes;

public abstract class Animal {
	public abstract String makeSound();
}