package com.cakes;

public interface Command {

	public void execute();
	
}