package com.cakes;

public class Dinner {

	public void makeDinner() {
		System.out.println("Dinner is being made");
	}

}