package com.cakes;

public class Lunch {

	public void makeLunch() {
		System.out.println("Lunch is being made");
	}

}