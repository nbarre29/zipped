package demo;

public class FacadeDemo {

	public static void main(String[] args) {

		Facade facade = new Facade();

		int x = 3;
		System.out.println("Cube of " + x + ":" + facade.cubeX(3));
		System.out.println("Cube of " + x + " times 2:" + facade.cubeXTimes2(3));
		System.out.println(x + " to sixth power times 2:" + facade.xToSixthPowerTimes2(3));

	}

}

/*
OUTPUT:::
Cube of 3:27
Cube of 3 times 2:54
3 to sixth power times 2:1458
*/
