package demo;

public class Class1 {

	public int doSomethingComplicated(int x) {
		return x * x * x;
	}

}
