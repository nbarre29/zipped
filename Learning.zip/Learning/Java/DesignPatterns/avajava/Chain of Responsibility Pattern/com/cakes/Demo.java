package com.cakes;

public class Demo {

	public static void main(String[] args) {
		PlanetHandler chain = setUpChain();

		chain.handleRequest(PlanetEnum.VENUS);
		chain.handleRequest(PlanetEnum.MERCURY);
		chain.handleRequest(PlanetEnum.EARTH);
		chain.handleRequest(PlanetEnum.JUPITER);
	}

	public static PlanetHandler setUpChain() {
		PlanetHandler mercuryHandler = new MercuryHandler();
		PlanetHandler venusHandler = new VenusHandler();
		PlanetHandler earthHandler = new EarthHandler();

		mercuryHandler.setSuccessor(venusHandler);
		venusHandler.setSuccessor(earthHandler);

		return mercuryHandler;
	}

}

/*
OUTPUT:::
MercuryHandler doesn't handle VENUS
VenusHandler handles VENUS
Venus is poisonous.

MercuryHandler handles MERCURY
Mercury is hot.

MercuryHandler doesn't handle EARTH
VenusHandler doesn't handle EARTH
EarthHandler handles EARTH
Earth is comfortable.

MercuryHandler doesn't handle JUPITER
VenusHandler doesn't handle JUPITER
EarthHandler doesn't handle JUPITER
*/