package com.cakes.animals;

public class Tyrannosaurus extends Animal {

	@Override
	public String makeSound() {
		return "Roar";
	}

}
