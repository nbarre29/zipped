package com.cakes.animals;

public abstract class Animal {
	public abstract String makeSound();
}