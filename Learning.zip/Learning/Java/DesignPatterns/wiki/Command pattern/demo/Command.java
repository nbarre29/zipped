package demo;

/* The Command interface */
public interface Command {
   void execute();
}
