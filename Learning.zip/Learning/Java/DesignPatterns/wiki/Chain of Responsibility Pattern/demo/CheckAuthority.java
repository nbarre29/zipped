package demo;

import java.io.BufferedReader;
import java.io.InputStreamReader;

class CheckAuthority {
    public static void main(String[] args) {
        ManagerPPower manager = new ManagerPPower();
        DirectorPPower director = new DirectorPPower();
        VicePresidentPPower vp = new VicePresidentPPower();
        PresidentPPower president = new PresidentPPower();
        manager.setSuccessor(director);
        director.setSuccessor(vp);
        vp.setSuccessor(president);
 
        // Press Ctrl+C to end.
        try {
            while (true) {
                System.out.println("Enter the amount to check who should approve your expenditure.");
                System.out.print(">");
                double d = Double.parseDouble(new BufferedReader(new InputStreamReader(System.in)).readLine());
                manager.processRequest(new PurchaseRequest(0, d, "General"));
           }
        } catch(Exception e) {
            System.exit(1);
        }  
    }
}

/*
OUTPUT::
Enter the amount to check who should approve your expenditure.
>15000
Vice President will approve $15000.0
Enter the amount to check who should approve your expenditure.
>222
Manager will approve $222.0
Enter the amount to check who should approve your expenditure.
>300
Manager will approve $300.0
Enter the amount to check who should approve your expenditure.
>5000000
Your request for $5000000.0 needs a board meeting!
Enter the amount to check who should approve your expenditure.
>1200
Manager will approve $1200.0
Enter the amount to check who should approve your expenditure.
>
*/
