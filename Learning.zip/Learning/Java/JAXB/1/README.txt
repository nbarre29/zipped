https://www.youtube.com/watch?v=4iFHtnYXBtw (Writing and Reading XML with JAXB)

https://adambien.blog/roller/abien/entry/from_pojo_to_xml_and