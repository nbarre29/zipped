package com.tech.designpatterns.facade;

public interface Phone {

    String build();
}
